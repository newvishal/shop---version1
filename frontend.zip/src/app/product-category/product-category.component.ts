import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder ,FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
import { CategoryService } from '../service/category.service';
import { ToastrManager } from 'ng6-toastr-notifications';
@Component({
  selector: 'app-product-category',
  templateUrl: './product-category.component.html',
  styleUrls: ['./product-category.component.css']
})
export class ProductCategoryComponent implements OnInit {

  public categorys: any = [];
  @ViewChild('categoryTable') Table;
  public dataTable: any;
  constructor(private fb: FormBuilder,
    private service: CategoryService,
    public toastr: ToastrManager
  ) { 

    this.categoryForm = this.fb.group({
      category_name: ['', [Validators.required, Validators.minLength(4)]],
      status: ['',Validators.required]
    });
  }
  categoryForm: FormGroup;
  // convenience getter for easy access to form fields
  get f() { return this.categoryForm.controls; }
  ngOnInit() {
    this.loadProducts();
  }

  loadProducts(){
    this.service.getCategorys().subscribe(
        categoryData => {
          this.categorys = categoryData;
          this.dataTable = jQuery(this.Table.nativeElement);
          setTimeout(()=>{this.dataTable.DataTable();}, 2000);
        }
    );
  }
  onSubmit(values) {
    if (this.categoryForm.invalid) {
        return;
    }else{
        const categoryData = new FormData();
        categoryData.append('category_name', values.category_name);
        categoryData.append('status', values.status);
        this.service.createCategory(categoryData).subscribe(result => {
          this.toastr.successToastr('Category Added successfull', 'Success!');
        }); 
        this.loadProducts();
    }
  }
   

   
  

}
