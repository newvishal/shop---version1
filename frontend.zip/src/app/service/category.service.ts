import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  public url = 'http://localhost/angular-php/backend/';

  constructor(private http: HttpClient) { }

  createCategory(data){
    return this.http.post(this.url + 'product-category.php', data);
  }
  getCategorys(){
    return this.http.get(this.url + 'get-product-category.php');
  }
}
